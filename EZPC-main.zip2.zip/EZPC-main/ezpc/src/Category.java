import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Category{

    public static void main(String[] args) {
        // Sample data setup
        HashMap<String, List<String>> partsData = new HashMap<>();
        partsData.put("CPU", List.of("Intel i9", "AMD Ryzen 9"));
        partsData.put("Memory", List.of("Corsair 16GB RAM", "Kingston 8GB RAM"));
        partsData.put("Storage", List.of("Samsung SSD 1TB", "Western Digital HDD 2TB"));
        partsData.put("GPU", List.of("Samsung SSD 1TB", "Western Digital HDD 2TB"));
        partsData.put("CPUCooler", List.of("Samsung SSD 1TB", "Western Digital HDD 2TB"));
        partsData.put("Motherboard", List.of("Samsung SSD 1TB", "Western Digital HDD 2TB"));
        partsData.put("PowerSupply", List.of("Samsung SSD 1TB", "Western Digital HDD 2TB"));

        // Initialize scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Display available categories
        System.out.println("Available categories: " + partsData.keySet());
        System.out.print("Enter a category to view parts: ");

        // User input for category
        String selectedCategory = scanner.nextLine().trim();

        // Validate and display parts list
        if (partsData.containsKey(selectedCategory)) {
            System.out.println("Parts in category '" + selectedCategory + "':");
            for (String part : partsData.get(selectedCategory)) {
                System.out.println("- " + part);
            }
        } else {
            System.out.println("Category not found. Please enter a valid category.");
        }

        scanner.close();
    }
}
