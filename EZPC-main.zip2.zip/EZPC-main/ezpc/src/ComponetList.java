import javax.swing.*;

public class ComponetList extends JFrame {
}
