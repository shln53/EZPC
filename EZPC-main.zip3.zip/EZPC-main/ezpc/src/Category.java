import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Category extends JFrame {
    public Category() {
        setTitle("Category");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Layout 설정
        setLayout(new BorderLayout());

        // 카테고리 제목
        JLabel titleLabel = new JLabel("Choose Category", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        // 카테고리 버튼 패널
        JPanel categoryPanel = new JPanel();
        categoryPanel.setLayout(new GridLayout(6, 1, 10, 10));

        // 각 카테고리 버튼
        JButton cpuButton = new JButton("CPU");
        JButton cpuCoolerButton = new JButton("CPU Coolers");
        JButton motherboardButton = new JButton("Motherboards");
        JButton memoryButton = new JButton("Memory");
        JButton storageButton = new JButton("Storage");
        JButton powerSupplyButton = new JButton("Power Supplies");

        // 각 카테고리 버튼에 이벤트 리스너 추가
        cpuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPartList("CPU");
            }
        });
        cpuCoolerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPartList("CPU Coolers");
            }
        });
        motherboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPartList("Motherboards");
            }
        });
        memoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPartList("Memory");
            }
        });
        storageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPartList("Storage");
            }
        });
        powerSupplyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPartList("Power Supplies");
            }
        });

        // 카테고리 버튼을 패널에 추가
        categoryPanel.add(cpuButton);
        categoryPanel.add(cpuCoolerButton);
        categoryPanel.add(motherboardButton);
        categoryPanel.add(memoryButton);
        categoryPanel.add(storageButton);
        categoryPanel.add(powerSupplyButton);

        add(categoryPanel, BorderLayout.CENTER);
    }

    // 부품 목록 화면을 띄우는 메서드
    private void showPartList(String category) {
        ComponentList componentListMenu = new ComponentList(category);
        componentListMenu.setVisible(true);  // 인스턴스 메서드로 호출
        this.dispose();  // 현재 카테고리 메뉴를 닫음
    }

    public static void main(String[] args) {
        // 카테고리 화면 실행
        SwingUtilities.invokeLater(() -> {
            new Category().setVisible(true);
        });
    }
}
