import javax.swing.*;
import java.awt.*;

public class ComponentList extends JFrame {
    private String category;

    public ComponentList(String category) {
        this.category = category;

        setTitle(category + " 부품 목록");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Layout 설정
        setLayout(new BorderLayout());

        // 부품 목록 제목
        JLabel titleLabel = new JLabel(category + " 부품 목록", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        // 부품 목록 패널
        JPanel partPanel = new JPanel();
        partPanel.setLayout(new GridLayout(10, 1, 10, 10));

        // 예시 부품 목록 (여기에 실제 부품 목록을 추가할 수 있음)
        for (int i = 1; i <= 10; i++) {
            partPanel.add(new JButton(category + " 부품 " + i));
        }

        add(partPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        // 부품 목록 화면 실행
        SwingUtilities.invokeLater(() -> {
            new ComponentList("CPU").setVisible(true);  // 예시로 CPU 부품 목록을 보여줌
        });
    }
}
