import javax.swing.*;

public class GameSpecManagement extends JFrame {
}
