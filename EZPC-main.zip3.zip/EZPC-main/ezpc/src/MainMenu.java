import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("EZPC");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Layout 설정
        setLayout(new BorderLayout());

        // 시스템 제목
        JLabel titleLabel = new JLabel("EZPC", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        // 메뉴 패널
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(3, 1, 10, 10));

        // 부품 리스트 버튼
        JButton partsListButton = new JButton("부품 리스트");
        menuPanel.add(partsListButton);

        // 컴퓨터 부품 버튼
        JButton computerPartsButton = new JButton("컴퓨터 부품");
        menuPanel.add(computerPartsButton);

        // 관리자 영역 버튼
        JButton adminAreaButton = new JButton("관리자 영역");
        menuPanel.add(adminAreaButton);

        add(menuPanel, BorderLayout.CENTER);

        // 컴퓨터 부품 버튼 클릭 시 카테고리 선택 화면 열기
        computerPartsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openCategoryScreen();  // Category 화면을 여는 메서드 호출
            }
        });
    }

    // 카테고리 화면을 여는 메서드
    private void openCategoryScreen() {
        Category categoryScreen = new Category();
        categoryScreen.setVisible(true);  // Category 화면 보이기
        this.dispose();  // 현재 MainMenu 화면을 닫기
    }

    public static void main(String[] args) {
        // 메인 화면 실행
        SwingUtilities.invokeLater(() -> {
            new MainMenu().setVisible(true);
        });
    }
}
