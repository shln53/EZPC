import java.util.*;

class Part {
    private String name;
    private double price;
    private int performance;
    private Date releaseDate;

    public Part(String name, double price, int performance, Date releaseDate) {
        this.name = name;
        this.price = price;
        this.performance = performance;
        this.releaseDate = releaseDate;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getPerformance() {
        return performance;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void displayDetails() {
        System.out.println("\nPart Details:");
        System.out.println("Name: " + name);
        System.out.println("Price: $" + price);
        System.out.println("Performance: " + performance);
        System.out.println("Release Date: " + releaseDate);
    }
}

class PartManagementSystem {

    public static void main(String[] args) {
        // Sample parts list
        List<Part> parts = new ArrayList<>();
        parts.add(new Part("Intel i9", 500.00, 95, new GregorianCalendar(2021, Calendar.MARCH, 1).getTime()));
        parts.add(new Part("AMD Ryzen 9", 450.00, 90, new GregorianCalendar(2021, Calendar.JANUARY, 15).getTime()));
        parts.add(new Part("Corsair 16GB RAM", 150.00, 75, new GregorianCalendar(2020, Calendar.JUNE, 10).getTime()));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Main menu
            System.out.println("\nChoose an option:");
            System.out.println("1. Sort parts");
            System.out.println("2. Search parts");
            System.out.println("3. View part details");
            System.out.println("4. Exit");
            System.out.print("Enter your choice (1-4): ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 4) {
                System.out.println("Exiting system. Goodbye!");
                break;
            }

            switch (choice) {
                case 1: // Sort parts
                    System.out.println("\nChoose a sorting criteria:");
                    System.out.println("1. Price");
                    System.out.println("2. Performance");
                    System.out.println("3. Release Date");
                    System.out.print("Enter your choice (1-3): ");
                    int sortChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (sortChoice) {
                        case 1:
                            parts.sort(Comparator.comparingDouble(Part::getPrice));
                            break;
                        case 2:
                            parts.sort(Comparator.comparingInt(Part::getPerformance).reversed());
                            break;
                        case 3:
                            parts.sort(Comparator.comparing(Part::getReleaseDate));
                            break;
                        default:
                            System.out.println("Invalid sorting choice.");
                            continue;
                    }

                    System.out.println("\nSorted Parts List:");
                    for (Part part : parts) {
                        System.out.println(part.getName());
                    }
                    break;

                case 2: // Search parts
                    System.out.print("Enter a keyword to search for parts: ");
                    String keyword = scanner.nextLine().trim().toLowerCase();
                    List<Part> searchResults = new ArrayList<>();
                    for (Part part : parts) {
                        if (part.getName().toLowerCase().contains(keyword)) {
                            searchResults.add(part);
                        }
                    }

                    if (searchResults.isEmpty()) {
                        System.out.println("No results found for the keyword: " + keyword);
                    } else {
                        System.out.println("\nSearch results for keyword '" + keyword + "':");
                        for (Part result : searchResults) {
                            System.out.println(result.getName());
                        }
                    }
                    break;

                case 3: // View part details
                    System.out.println("\nAvailable Parts:");
                    for (int i = 0; i < parts.size(); i++) {
                        System.out.printf("%d. %s\n", i + 1, parts.get(i).getName());
                    }

                    System.out.print("\nEnter the number of the part to view details (or 0 to exit): ");
                    int detailChoice = scanner.nextInt();

                    if (detailChoice == 0) {
                        System.out.println("Returning to main menu.");
                    } else if (detailChoice > 0 && detailChoice <= parts.size()) {
                        parts.get(detailChoice - 1).displayDetails();
                    } else {
                        System.out.println("Invalid selection. Please choose a valid part number.");
                    }
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
