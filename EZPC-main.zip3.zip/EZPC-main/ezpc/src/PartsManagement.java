import javax.swing.*;

public class PartsManagement extends JFrame {
}
